import { api } from "./client";

/** =========================
 *  TIPOS DE RESPUESTA
 *  ========================= */

export type UserSummary = {
  exchange: {
    usuario_id: number;
    email: string;
    intercambios_hechos: number;
    compras_creditos: number;
    creditos_comprados: string | number;
    tiene_suscripcion: boolean;
    puntaje: number;
    rank_intercambios: number;
  } | null;
  wallet_monthly: {
    mes: string; // date ISO
    delta_creditos: string | number;
    total_movimientos: number;
  }[];
  impacto: {
    usuario_id: number;
    total_co2_evitado: string | number;
    total_energia_ahorrada: string | number;
    total_agua_preservada: string | number;
    total_residuos_evitados: string | number;
    total_creditos_ganados: string | number;
    updated_at: string;
  } | null;
};

export type UserRankingMe = {
  usuario_id: number;
  email: string;
  intercambios_hechos: number;
  compras_creditos: number;
  creditos_comprados: string | number;
  tiene_suscripcion: boolean;
  puntaje: number;
  rank_intercambios: number;
};

export type UserRankingItem = {
  usuario_id: number;
  intercambios_hechos: number;
  rank_intercambios: number;
  nombre: string;
};

export type UserRankingResponse = {
  me: UserRankingMe | null;
  top10: UserRankingItem[];
};

export type UserHistoryItem = {
  intercambio_id: number;
  monto_credito: number;
  estado: string;
  fecha_de_aceptacion: string;
  fecha_de_expiracion: string;
  fecha_completado: string | null;
  comprador_id: number;
  vendedor_id: number;
  propuesta_id: number;
  publicacion_id: number;
  publicacion_titulo: string;
  publicacion_valor_creditos: number;
  categoria_id: number;
  categoria_nombre: string;
  rol: "venta" | "compra" | null;
};

export type OrgVentaItem = {
  mes: string; // date ISO (primer día del mes)
  total_cred: string | number;
  total_ops: number;
};

export type OrgWalletItem = {
  mes: string;
  delta_creditos: string | number;
  total_movimientos: number;
};

export type OrgTopCategoriaItem = {
  categoria_id: number;
  categoria: string;
  intercambios: number;
};

/** =========================
 *  WRAPPERS API
 *  =========================
 *  OJO: asumo que en el backend montaste:
 *  app.use("/api/report", reportRoutes);
 *  Ajusta el prefijo si es distinto.
 */

/** Resumen de usuario logueado */
export const getUserSummary = async () => {
  const r = await api.get<{ ok: boolean; data: UserSummary }>(
    `/api/report/user/me/summary`
  );
  return (r as any).data ?? (r as any);
};

/** Ranking del usuario logueado + top 10 */
export const getUserRanking = async () => {
  const r = await api.get<{ ok: boolean; data: UserRankingResponse }>(
    `/api/report/user/me/ranking`
  );
  return (r as any).data ?? (r as any);
};

/** Historial de intercambios del usuario logueado */
export const getUserHistory = async () => {
  const r = await api.get<{ ok: boolean; data: UserHistoryItem[] }>(
    `/api/report/user/me/history`
  );
  return (r as any).data ?? (r as any);
};

/** Ventas del emprendedor/ONG por mes */
export const getOrgVentas = async () => {
  const r = await api.get<{ ok: boolean; data: OrgVentaItem[] }>(
    `/api/report/org/me/ventas`
  );
  return (r as any).data ?? (r as any);
};

/** Movimientos mensuales de billetera del emprendedor/ONG */
export const getOrgWallet = async () => {
  const r = await api.get<{ ok: boolean; data: OrgWalletItem[] }>(
    `/api/report/org/me/wallet`
  );
  return (r as any).data ?? (r as any);
};

/** Top categorías de intercambios (para el emprendedor/ONG) */
export const getOrgTopCategorias = async () => {
  const r = await api.get<{ ok: boolean; data: OrgTopCategoriaItem[] }>(
    `/api/report/org/me/top-categorias`
  );
  return (r as any).data ?? (r as any);
};
