import React, { useEffect, useState } from "react";
import {
  getOrgVentas,
  getOrgWallet,
  getOrgTopCategorias,
} from "../../api/reportes.usuario";
import type {
  OrgVentaItem,
  OrgWalletItem,
  OrgTopCategoriaItem,
} from "../../api/reportes.usuario";

const OrgReportsPage: React.FC = () => {
  const [ventas, setVentas] = useState<OrgVentaItem[]>([]);
  const [wallet, setWallet] = useState<OrgWalletItem[]>([]);
  const [topCategorias, setTopCategorias] = useState<OrgTopCategoriaItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const load = async () => {
      try {
        setLoading(true);
        setError(null);
        const [_ventas, _wallet, _topCat] = await Promise.all([
          getOrgVentas(),
          getOrgWallet(),
          getOrgTopCategorias(),
        ]);
        setVentas(_ventas);
        setWallet(_wallet);
        setTopCategorias(_topCat);
      } catch (err: any) {
        console.error(err);
        setError(err.message ?? "Error cargando reportes de organización");
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  if (loading) return <div className="p-4">Cargando reportes...</div>;
  if (error) return <div className="p-4 text-red-600">Error: {error}</div>;

  return (
    <div className="p-4 space-y-6">
      <h1 className="text-2xl font-bold mb-4">Reportes de mi organización</h1>

      {/* Ventas por mes */}
      <section className="bg-white rounded shadow p-4">
        <h2 className="text-xl font-semibold mb-2">Ventas por mes</h2>
        <table className="min-w-full text-sm border border-gray-200">
          <thead className="bg-gray-100">
            <tr>
              <th className="px-3 py-2 border-b">Mes</th>
              <th className="px-3 py-2 border-b">Créditos</th>
              <th className="px-3 py-2 border-b">Operaciones</th>
            </tr>
          </thead>
          <tbody>
            {ventas.length ? (
              ventas.map((v, i) => (
                <tr key={i} className="odd:bg-white even:bg-gray-50">
                  <td className="px-3 py-1 border-b">
                    {new Date(v.mes).toLocaleDateString("es-BO", {
                      year: "numeric",
                      month: "short",
                    })}
                  </td>
                  <td className="px-3 py-1 border-b">{v.total_cred ?? 0}</td>
                  <td className="px-3 py-1 border-b">{v.total_ops}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td className="px-3 py-2" colSpan={3}>
                  Sin ventas aún.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </section>

      {/* Wallet mensual */}
      <section className="bg-white rounded shadow p-4">
        <h2 className="text-xl font-semibold mb-2">Movimientos de billetera</h2>
        <table className="min-w-full text-sm border border-gray-200">
          <thead className="bg-gray-100">
            <tr>
              <th className="px-3 py-2 border-b">Mes</th>
              <th className="px-3 py-2 border-b">Delta créditos</th>
              <th className="px-3 py-2 border-b">Movimientos</th>
            </tr>
          </thead>
          <tbody>
            {wallet.length ? (
              wallet.map((w, i) => (
                <tr key={i} className="odd:bg-white even:bg-gray-50">
                  <td className="px-3 py-1 border-b">
                    {new Date(w.mes).toLocaleDateString("es-BO", {
                      year: "numeric",
                      month: "short",
                    })}
                  </td>
                  <td className="px-3 py-1 border-b">{w.delta_creditos ?? 0}</td>
                  <td className="px-3 py-1 border-b">{w.total_movimientos}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td className="px-3 py-2" colSpan={3}>
                  Sin movimientos aún.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </section>

      {/* Top categorías */}
      <section className="bg-white rounded shadow p-4">
        <h2 className="text-xl font-semibold mb-2">Categorías con más intercambios</h2>
        <table className="min-w-full text-sm border border-gray-200">
          <thead className="bg-gray-100">
            <tr>
              <th className="px-3 py-2 border-b">Categoría</th>
              <th className="px-3 py-2 border-b">Intercambios completados</th>
            </tr>
          </thead>
          <tbody>
            {topCategorias.length ? (
              topCategorias.map((c) => (
                <tr key={c.categoria_id} className="odd:bg-white even:bg-gray-50">
                  <td className="px-3 py-1 border-b">{c.categoria}</td>
                  <td className="px-3 py-1 border-b">{c.intercambios}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td className="px-3 py-2" colSpan={2}>
                  Aún no hay intercambios.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </section>
    </div>
  );
};

export default OrgReportsPage;
