import React, { useEffect, useState } from "react";
import {
  getUserSummary,
  getUserRanking,
  getUserHistory,
} from "../../api/reportes.usuario";
import type {
  UserSummary,
  UserRankingResponse,
  UserHistoryItem,
} from "../../api/reportes.usuario";

const UserReportsPage: React.FC = () => {
  const [summary, setSummary] = useState<UserSummary | null>(null);
  const [ranking, setRanking] = useState<UserRankingResponse | null>(null);
  const [history, setHistory] = useState<UserHistoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const load = async () => {
      try {
        setLoading(true);
        setError(null);

        const [_summary, _ranking, _history] = await Promise.all([
          getUserSummary(),
          getUserRanking(),
          getUserHistory(),
        ]);

        setSummary(_summary);
        setRanking(_ranking);
        setHistory(_history);
      } catch (err: any) {
        console.error(err);
        setError(err.message ?? "Error cargando reportes de usuario");
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  if (loading) return <div className="p-4">Cargando mis reportes...</div>;
  if (error) return <div className="p-4 text-red-600">Error: {error}</div>;

  const me = ranking?.me;

  return (
    <div className="p-4 space-y-6">
      <h1 className="text-2xl font-bold mb-4">Mis reportes</h1>

      {/* Resumen de participación */}
      <section className="bg-white rounded shadow p-4 space-y-2">
        <h2 className="text-xl font-semibold mb-2">Participación</h2>
        {me ? (
          <>
            <p>
              <strong>Intercambios completados:</strong> {me.intercambios_hechos}
            </p>
            <p>
              <strong>Compras de créditos:</strong> {me.compras_creditos}
            </p>
            <p>
              <strong>Créditos comprados:</strong> {me.creditos_comprados ?? 0}
            </p>
            <p>
              <strong>Suscripción premium:</strong>{" "}
              {me.tiene_suscripcion ? "Sí" : "No"}
            </p>
            <p>
              <strong>Puntaje:</strong> {me.puntaje}
            </p>
            <p>
              <strong>Posición en ranking por intercambios:</strong>{" "}
              {me.rank_intercambios}
            </p>
          </>
        ) : (
          <p>No se encontraron datos de participación.</p>
        )}
      </section>

      {/* Impacto ambiental personal */}
      <section className="bg-white rounded shadow p-4 space-y-2">
        <h2 className="text-xl font-semibold mb-2">Mi Impacto Ambiental</h2>
        {summary?.impacto ? (
          <>
            <p>
              <strong>CO₂ evitado:</strong> {summary.impacto.total_co2_evitado}
            </p>
            <p>
              <strong>Energía ahorrada:</strong>{" "}
              {summary.impacto.total_energia_ahorrada}
            </p>
            <p>
              <strong>Agua preservada:</strong>{" "}
              {summary.impacto.total_agua_preservada}
            </p>
            <p>
              <strong>Residuos evitados:</strong>{" "}
              {summary.impacto.total_residuos_evitados}
            </p>
            <p>
              <strong>Créditos ganados por impacto:</strong>{" "}
              {summary.impacto.total_creditos_ganados}
            </p>
          </>
        ) : (
          <p>Todavía no generaste impacto registrado.</p>
        )}
      </section>

      {/* Wallet mensual */}
      <section className="bg-white rounded shadow p-4">
        <h2 className="text-xl font-semibold mb-2">Movimientos mensuales de créditos</h2>
        <table className="min-w-full text-sm border border-gray-200">
          <thead className="bg-gray-100">
            <tr>
              <th className="px-3 py-2 text-left border-b">Mes</th>
              <th className="px-3 py-2 text-left border-b">Delta créditos</th>
              <th className="px-3 py-2 text-left border-b">Movimientos</th>
            </tr>
          </thead>
          <tbody>
            {summary?.wallet_monthly.length ? (
              summary.wallet_monthly.map((w, i) => (
                <tr key={i} className="odd:bg-white even:bg-gray-50">
                  <td className="px-3 py-1 border-b">
                    {new Date(w.mes).toLocaleDateString("es-BO", {
                      year: "numeric",
                      month: "short",
                    })}
                  </td>
                  <td className="px-3 py-1 border-b">{w.delta_creditos ?? 0}</td>
                  <td className="px-3 py-1 border-b">{w.total_movimientos}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td className="px-3 py-2" colSpan={3}>
                  Sin movimientos aún.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </section>

      {/* Historial de intercambios */}
      <section className="bg-white rounded shadow p-4">
        <h2 className="text-xl font-semibold mb-2">Historial de Intercambios</h2>
        <div className="overflow-x-auto">
          <table className="min-w-full text-sm border border-gray-200">
            <thead className="bg-gray-100">
              <tr>
                <th className="px-3 py-2 border-b">ID</th>
                <th className="px-3 py-2 border-b">Rol</th>
                <th className="px-3 py-2 border-b">Estado</th>
                <th className="px-3 py-2 border-b">Título</th>
                <th className="px-3 py-2 border-b">Créditos</th>
                <th className="px-3 py-2 border-b">Categoría</th>
                <th className="px-3 py-2 border-b">Fecha completado</th>
              </tr>
            </thead>
            <tbody>
              {history.length ? (
                history.map((h) => (
                  <tr key={h.intercambio_id} className="odd:bg-white even:bg-gray-50">
                    <td className="px-3 py-1 border-b">{h.intercambio_id}</td>
                    <td className="px-3 py-1 border-b">{h.rol ?? "-"}</td>
                    <td className="px-3 py-1 border-b">{h.estado}</td>
                    <td className="px-3 py-1 border-b">{h.publicacion_titulo}</td>
                    <td className="px-3 py-1 border-b">{h.monto_credito}</td>
                    <td className="px-3 py-1 border-b">{h.categoria_nombre}</td>
                    <td className="px-3 py-1 border-b">
                      {h.fecha_completado
                        ? new Date(h.fecha_completado).toLocaleString("es-BO")
                        : "-"}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td className="px-3 py-2" colSpan={7}>
                    No tienes intercambios todavía.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};

export default UserReportsPage;
